__author__ = 'Jean-Bernard Ratte - jean.bernard.ratte@unary.ca'
